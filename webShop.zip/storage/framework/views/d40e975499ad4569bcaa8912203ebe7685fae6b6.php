

<?php $__env->startSection("content"); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="breadcrumb">
            <ul>
                <li><a href="<?php echo e(route("home")); ?>" title="پیشخوان">پیشخوان</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="row no-gutters">
                <div class="col-12 bg-white">
                    <p class="box__title">ایجاد دسته بندی جدید</p>
                    <form action="<?php echo e(route("permissions.update",$role->id)); ?>" method="post" class="padding-30">
                        <?php echo method_field("patch"); ?>
                        <?php echo csrf_field(); ?>
                        <input type="text" name="name" required placeholder="نام دسته بندی"
                               class="text" value="<?php echo e($role->name); ?>">


                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <p class="box__title margin-bottom-15">انتخاب مجوز ها</p>



                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="ui-checkbox">
                                <input type="checkbox" name="permissions[<?php echo e($permission->name); ?>]"
                                       class="sub-checkbox" data-id="1"
                                       <?php if($role->hasPermissionTo($permission)): ?>
                                               checked
                                               <?php endif; ?>
                                       value="<?php echo e($permission->name); ?>"
                                >
                                <span class="checkmark"></span>
                                <?php echo app('translator')->get($permission->name); ?>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>


                        <?php $__errorArgs = ['permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <br>




                        <button type="submit" class="btn btn-webamooz_net">بروزرسانی</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\RolePermissions\Providers./../Resources/Views/edit.blade.php ENDPATH**/ ?>