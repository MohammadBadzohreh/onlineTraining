<div class="col-4 bg-white">
    <p class="box__title">ایجاد نقش کاربری جدید</p>
    <form action="<?php echo e(route("permissions.store")); ?>" method="post" class="padding-30">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" required placeholder="نام نقش کاربری"
               class="text <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old("name")); ?>">


        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <p class="box__title margin-bottom-15">مجوز ها</p>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="ui-checkbox">
                <input type="checkbox" name="permissions[<?php echo e($permission->name); ?>]"
                       class="sub-checkbox" data-id="1"
                       <?php if(is_array(old("permissions")) &&
                        array_key_exists($permission->name,old("permissions"))): ?>
                           checked
                           <?php endif; ?>
                        value="<?php echo e($permission->name); ?>"
                >
                <span class="checkmark"></span>
                <?php echo app('translator')->get($permission->name); ?>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br>
        <button type="submit" class="btn btn-webamooz_net">اضافه کردن</button>
    </form>
</div>



<?php /**PATH D:\projects\webShop\moduls\Badzohreh\RolePermissions\Providers./../Resources/Views/create.blade.php ENDPATH**/ ?>