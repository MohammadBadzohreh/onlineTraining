

<?php $__env->startSection("content"); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content padding-0">
            <p class="box__title">ایجاد دوره جدید</p>
            <div class="row no-gutters bg-white">
                <div class="col-12">
                    <form action="<?php echo e(route("course.store")); ?>" method="post" enctype="multipart/form-data" class="padding-30">
                        <?php echo csrf_field(); ?>

                         <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'title','placeholder' => 'عنوان دوره']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'slug','placeholder' => 'نام انگلیسی دوره']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left','required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                        <div class="d-flex multi-text">
                             <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'priority','placeholder' => 'ردیف دوره']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left mlg-15']); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'price','placeholder' => 'مبلغ دوره']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left text mlg-15','required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'percent','placeholder' => 'درصد مدرس']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left text mlg-15','required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>

                         <?php if (isset($component)) { $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectBox::class, ['name' => 'teacher_id']); ?>
<?php $component->withName('select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
                            <option value="">انتخاب مدرس دوره</option>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($teacher->id); ?>"
                                        <?php if($teacher->id == old('teacher_id')): ?> selected <?php endif; ?>
                                ><?php echo e($teacher->name); ?></option>

                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <option value="1">mohammad badzohreh</option>

                         <?php if (isset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756)): ?>
<?php $component = $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756; ?>
<?php unset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                        <ul class="tags-input-ul mb-0 mt-15">
                            <li class="tags-new">
                                <input type="text" class="" placeholder="برچسب ها">
                            </li>
                        </ul>


                         <?php if (isset($component)) { $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectBox::class, ['name' => 'type']); ?>
<?php $component->withName('select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php $__currentLoopData = \Badzohreh\Course\Models\Course::$TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>"
                                        <?php if($type == old('type')): ?> selected <?php endif; ?>
                                ><?php echo app('translator')->get($type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756)): ?>
<?php $component = $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756; ?>
<?php unset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectBox::class, ['name' => 'status']); ?>
<?php $component->withName('select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php $__currentLoopData = \Badzohreh\Course\Models\Course::$STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status); ?>"
                                        <?php if($status == old('status')): ?> selected <?php endif; ?>

                                ><?php echo app('translator')->get($status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756)): ?>
<?php $component = $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756; ?>
<?php unset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectBox::class, ['name' => 'category_id']); ?>
<?php $component->withName('select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <option value="">دسته بندی</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756)): ?>
<?php $component = $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756; ?>
<?php unset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginal39539b0b265662580341faed89579bf8b84763bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UploadedFile::class, ['name' => 'image','title' => 'انتخاب بنر دوره']); ?>
<?php $component->withName('uploaded-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal39539b0b265662580341faed89579bf8b84763bd)): ?>
<?php $component = $__componentOriginal39539b0b265662580341faed89579bf8b84763bd; ?>
<?php unset($__componentOriginal39539b0b265662580341faed89579bf8b84763bd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Textarea::class, ['placeholder' => 'توضیحات دوره','name' => 'body']); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <?php echo e(old("body")); ?>

                         <?php if (isset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890)): ?>
<?php $component = $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890; ?>
<?php unset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <br>
                        <button class="btn btn-webamooz_net">ایجاد دوره</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="js/tagsInput.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Course\Providers./../Resources/views/create.blade.php ENDPATH**/ ?>