<?php $__env->startSection("content"); ?>
    <main id="index">
        <article class="container article">
            <?php echo $__env->make("Front::layouts.ads", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("Front::layouts.top-info", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("Front::layouts.lastest-course", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("Front::layouts.popular-course", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </article>
    </main>
    <?php echo $__env->make("Front::layouts.blog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>









<?php echo $__env->make("Front::layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/index.blade.php ENDPATH**/ ?>