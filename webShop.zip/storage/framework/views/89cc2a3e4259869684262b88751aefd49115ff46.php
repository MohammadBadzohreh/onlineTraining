<div class="sidebar-banners">

    <div class="sidebar-pic">
        <a href="https://t.me/webmooz_net">
            <img src="img/telgram.png" alt="کانال تلگرام">
        </a>
    </div>

    <div class="sidebar-pic">
        <a href="https://t.me/webmooz_net">
            <img src="img/laravel-tel.png" alt="کانال تلگرام">
        </a>
    </div>
    <div class="sidebar-pic">
        <a href="https:webamooz.net/blog">
            <img src="img/podcast.png" alt="وبلاگ وب آموز">
        </a>
    </div>
    <div class="sidebar-pic">
        <a href="https://t.me/webmooz_net">
            <img src="img/workinja.png" alt="کانال تلگرام">
        </a>
    </div>
    <div class="sidebar-pic">
        <a href="https://t.me/webmooz_net">
            <img src="img/blog-pic.png" alt="کانال تلگرام">
        </a>
    </div>
</div>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/sidebar-banners.blade.php ENDPATH**/ ?>