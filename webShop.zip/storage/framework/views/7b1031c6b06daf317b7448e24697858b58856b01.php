
<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="/panel/css/jquery.toast.min.css" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="main-content padding-0 categories">
            <div class="row no-gutters">
                <div class="col-8 margin-left-10 margin-bottom-15 border-radius-3">
                    <p class="box__title">دسته بندی ها</p>
                    <div class="table__box">
                        <table class="table">
                            <thead role="rowgroup">
                            <tr role="row" class="title-row">
                                <th>شناسه</th>
                                <th>نام دسته بندی</th>
                                <th>نام انگلیسی دسته بندی</th>
                                <th>دسته پدر</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="">
                                    <td><a href=""><?php echo e($category->id); ?></a></td>
                                    <td><a href=""><?php echo e($category->title); ?></a></td>
                                    <td><?php echo e($category->slug); ?></td>
                                    <td><?php echo e($category->parent); ?></td>
                                    <td>
                                        <a href="" class="item-delete mlg-15"
                                           onclick="handleDeleteItem(event,'<?php echo e(route('categories.destroy',$category->id)); ?>')"
                                           title="حذف"></a>
                                        <a href="" target="_blank" class="item-eye mlg-15" title="مشاهده"></a>
                                        <a href="<?php echo e(route("categories.edit",$category->id)); ?>" class="item-edit "
                                           title="ویرایش"></a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo $__env->make("Categories::create", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("js"); ?>

    <script src="/panel/js/jquery.toast.min.js" type="text/javascript"></script>
    <script>
        function handleDeleteItem(event, route) {

            event.preventDefault();

            if (confirm('ایتم مورد نظر حذف شود؟')) {
                $.post(route, {_method: "delete", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {
                        event.target.closest('tr').remove();

                        $.toast({
                            heading: 'عملیات موفقیت آمیز',
                            text: 'ایتم مورد نظر با موفقیت حذف شد.',
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    })
                    .fail(function (response) {
                        $.toast({
                            heading: 'خطایی به وجود آمده است',
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    });
            }
        }


    </script>
<?php $__env->stopSection(); ?>







<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Category\Providers/../Resources/Views/detail.blade.php ENDPATH**/ ?>