<div class="ads d-none">
    <a href="" rel="nofollow noopener"><img src="img/ads/1440px/test.jpg" alt=""></a>
</div><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/ads.blade.php ENDPATH**/ ?>