<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css"/>
    <link rel="stylesheet" href="/panel/css/jquery.toast.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content">
            <div class="table__box">
                <table class="table">
                    <thead>
                    <tr class="title-row">
                        <th>عنوان دوره</th>
                        <th>تاریخ پرداخت</th>
                        <th>مقدار پرداختی</th>
                        <th>وضعیت پرداخت</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($payment->paymentable->title); ?></td>
                            <td><?php echo e(\Morilog\Jalali\Jalalian::fromCarbon($payment->created_at)->format("%d %B %Y")); ?></td>
                            <td><?php echo e($payment->amount); ?> تومان</td>
                            <td class="<?php if($payment->status == \Badzohreh\Payment\Models\Payment::STATUS_ACCEPTED): ?> text-success <?php else: ?> text-error <?php endif; ?>"><?php echo app('translator')->get($payment->status); ?></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Payment\Providers./../Resources/Views/purchases.blade.php ENDPATH**/ ?>