
<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="/panel/css/jquery.toast.min.css" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content padding-0 categories">
            <div class="row no-gutters">
                <div class="col-8 margin-left-10 margin-bottom-15 border-radius-3">
                    <p class="box__title">نقش های کاربری</p>
                    <div class="table__box">
                        <table class="table">
                            <thead role="rowgroup">
                            <tr role="row" class="title-row">
                                <th>شناسه</th>
                                <th>نام نقش کاربری</th>
                                <th>مجوز ها</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="">
                                    <td><a href=""><?php echo e($role->id); ?></a></td>
                                    <td><a href=""><?php echo e($role->name); ?></a></td>
                                    <td>
                                        <ul>
                                            <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li><?php echo app('translator')->get($permission->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>


                                    </td>
                                    <td>
                                        <a href="" class="item-delete mlg-15"
                                           onclick="handleDeleteItem(event,'<?php echo e(route('permissions.destroy',$role->id)); ?>')"
                                           title="حذف"></a>
                                        <a href="<?php echo e(route("permissions.edit",$role->id)); ?>" class="item-edit "
                                           title="ویرایش"></a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo $__env->make("RolePermissions::create", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="/panel/js/jquery.toast.min.js" type="text/javascript"></script>

    <script>




    function handleDeleteItem(event, route) {
            event.preventDefault();
            if (confirm("ایا از حذف این ایتم مطمئن هستید؟")) {

                $.post(route, {_method: "delete", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {

                        console.log("dd");
                        event.target.closest('tr').remove();

                        $.toast({
                            heading: 'عملیات موفقیت آمیز',
                            text: 'ایتم مورد نظر با موفقیت حذف شد.',
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    })
                    .fail(function (response) {
                        console.log("dd");
                        $.toast({
                            heading: 'خطایی به وجود آمده است',
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    });
            }
        }

    </script>
<?php $__env->stopSection(); ?>










<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\RolePermissions\Providers./../Resources/Views/detail.blade.php ENDPATH**/ ?>