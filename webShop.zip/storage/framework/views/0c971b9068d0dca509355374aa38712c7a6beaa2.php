<!doctype html>
<html lang="fa">
<?php echo $__env->make("Front::layouts.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<?php echo $__env->make("Front::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent("content"); ?>
<?php echo $__env->make("Front::layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="overlay"></div>

<?php echo $__env->make("Front::layouts.foot", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/master.blade.php ENDPATH**/ ?>