
<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="/panel/css/jquery.toast.min.css" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content padding-0 course__detial">
            <div class="row no-gutters  ">
                <div class="col-8 bg-white padding-30 margin-left-10 margin-bottom-15 border-radius-3">
                    <div class="margin-bottom-20 flex-wrap font-size-14 d-flex bg-white padding-0">
                        <p class="mlg-15">دوره مقدماتی تا پیشرفته لاراول</p>
                        <a class="color-2b4a83" href="<?php echo e(route("lessons.create",$course->id)); ?>">آپلود جلسه جدید</a>
                    </div>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(\Badzohreh\RolePermissions\Models\Permission::PERMISSION_MANAGE_COURSES
                                                         || \Badzohreh\RolePermissions\Models\Permission::PERMISSION_SUPER_ADMIN
                                                         )): ?>
                    <div class="d-flex item-center flex-wrap margin-bottom-15 operations__btns">
                            <button onclick="handleAcceptAll('<?php echo e(route("lesson.accpetAll",$course->id)); ?>');"
                                    class="btn all-confirm-btn">تایید همه جلسات
                            </button>
                            <button onclick="accpetMultiPle('<?php echo e(route("lesson.accpetSelected",$course->id)); ?>')"
                                    class="btn confirm-btn">تایید جلسات
                            </button>
                            <button  onclick="rejectMutiple('<?php echo e(route("lesson.rejectSelected",$course->id)); ?>')" class="btn reject-btn">رد جلسات</button>
                            <button class="btn delete-btn" onclick="multiple('<?php echo e(route("delete.multiple.lessons")); ?>')">حذف
                                جلسات
                            </button>

                        </div>
                        <?php endif; ?>

                    <div class="table__box">
                        <table class="table">
                            <thead role="rowgroup">
                            <tr role="row" class="title-row">
                                <th style="padding: 13px 30px;">
                                    <label class="ui-checkbox">
                                        <input type="checkbox" class="checkedAll">
                                        <span class="checkmark"></span>
                                    </label>
                                </th>
                                <th>شناسه</th>
                                <th>عنوان جلسه</th>
                                <th>عنوان فصل</th>
                                <th>مدت زمان جلسه</th>
                                <th>وضعیت تایید</th>
                                <th>سطح دسترسی</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="" data-row-id="<?php echo e($lesson->id); ?>">
                                    <td>
                                        <label class="ui-checkbox">
                                            <input type="checkbox" class="sub-checkbox" data-id="<?php echo e($lesson->id); ?>">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>
                                    <td><a href=""><?php echo e($lesson->number); ?></a></td>
                                    <td><a href=""><?php echo e($lesson->title); ?></a></td>
                                    <td><?php echo e($lesson->seasonTitle); ?></td>
                                    <td><?php echo e($lesson->time); ?></td>
                                    <td class="confirmation_status"><?php echo app('translator')->get($lesson->confirmation_staus); ?></td>
                                    <td class="status">
                                        <?php if($lesson->status == \Badzohreh\Course\Models\Lesson::STATUS_OPENED): ?>
                                            <?php if($lesson->is_free): ?>
                                                رایگان
                                            <?php else: ?>
                                                شرکت کنندگان
                                            <?php endif; ?>
                                        <?php else: ?>
                                            قفل
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href=""
                                           onclick="handleDeleteItem(event,'<?php echo e(route('lesson.destroy',[$course->id,$lesson->id])); ?>')"
                                           class="item-delete mlg-15" data-id="1" title="حذف"></a>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(\Badzohreh\RolePermissions\Models\Permission::PERMISSION_MANAGE_COURSES
                                                           || \Badzohreh\RolePermissions\Models\Permission::PERMISSION_SUPER_ADMIN
                                                           )): ?>                                            <a href="" class="item-reject mlg-15" onclick="handleChangeStatus(event,
                                                    '<?php echo e(route("lesson.reject",
                                                   $lesson->id)); ?>',
                                                    'ایا از رد این دوره مطمئن هستید؟',
                                                    'رد'
                                                    )" title="رد"></a>
                                            <a href="" class="item-lock mlg-15 text-success"
                                               onclick="handleChangeStatus(event,
                                                       '<?php echo e(route("lesson.unlock",
                                                   $lesson->id)); ?>',
                                                       'ایا از باز این دوره مطمئن هستید؟',
                                                       'باز',
                                                       true
                                                       )"
                                               title="باز"></a>
                                            <a href="" onclick="handleChangeStatus(event,
                                                    '<?php echo e(route("lesson.accpet",
                                                   $lesson->id)); ?>',
                                                    'ایا از تایید این دوره مطمئن هستید؟',
                                                    'تایید'
                                                    )" class="item-confirm mlg-15 " title="تایید"></a>


                                            <a href="" class="item-lock mlg-15 text-error"

                                               onclick="handleChangeStatus(event,
                                                       '<?php echo e(route("lesson.lock",
                                                   $lesson->id)); ?>',
                                                       'ایا از قفل این دوره مطمئن هستید؟',
                                                       'قفل',
                                                       true
                                                       )"
                                               title="قفل کردن"></a>

                                            <?php endif; ?>



                                        <a href="<?php echo e(route("lesson.edit",[$course->id,$lesson->id])); ?>" class="item-edit "
                                           title="ویرایش"></a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-4">

                    <div class="col-12 bg-white margin-bottom-15 border-radius-3">
                        <?php echo $__env->make("Course::seasons.create", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make("Course::seasons.showSeasson", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-12 bg-white margin-bottom-15 border-radius-3">


                        <p class="box__title">اضافه کردن دانشجو به دوره</p>
                        <form action="" method="post" class="padding-30">
                            <select name="" id="">
                                <option value="0">انتخاب کاربر</option>
                                <option value="1">mohammadniko3@gmail.com</option>
                                <option value="2">sayad@gamil.com</option>
                            </select>
                            <div class="dropdown-select wide " tabindex="0"><span class="current">انتخاب کاربر</span>
                                <div class="list">
                                    <div class="dd-search"><input id="txtSearchValue" autocomplete="off"
                                                                  onkeyup="filter()" class="dd-searchbox" type="text">
                                    </div>
                                    <ul>
                                        <li class="option selected" data-value="0" data-display-text="">انتخاب کاربر
                                        </li>
                                        <li class="option " data-value="1" data-display-text="">
                                            mohammadniko3@gmail.com
                                        </li>
                                        <li class="option " data-value="2" data-display-text="">sayad@gamil.com</li>
                                    </ul>
                                </div>
                            </div>
                            <input type="text" placeholder="مبلغ دوره" class="text">
                            <p class="box__title">کارمزد مدرس ثبت شود ؟</p>
                            <div class="notificationGroup">
                                <input id="course-detial-field-1" name="course-detial-field" type="radio" checked="">
                                <label for="course-detial-field-1">بله</label>
                            </div>
                            <div class="notificationGroup">
                                <input id="course-detial-field-2" name="course-detial-field" type="radio">
                                <label for="course-detial-field-2">خیر</label>
                            </div>
                            <button class="btn btn-webamooz_net">اضافه کردن</button>
                        </form>


                        <div class="table__box padding-30">
                            <table class="table">
                                <thead role="rowgroup">
                                <tr role="row" class="title-row">
                                    <th class="p-r-90">شناسه</th>
                                    <th>نام و نام خانوادگی</th>
                                    <th>ایمیل</th>
                                    <th>مبلغ (تومان)</th>
                                    <th>درامد شما</th>
                                    <th>عملیات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr role="row" class="">
                                    <td><a href="">1</a></td>
                                    <td><a href="">توفیق حمزه ای</a></td>
                                    <td><a href="">Mohammadniko3@gmail.com</a></td>
                                    <td><a href="">40000</a></td>
                                    <td><a href="">20000</a></td>
                                    <td>
                                        <a href="" class="item-delete mlg-15" title="حذف"></a>
                                        <a href="" class="item-edit " title="ویرایش"></a>
                                    </td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection("js"); ?>
    <script src="/panel/js/jquery.toast.min.js" type="text/javascript"></script>

    <script>
        function handleChangeStatus(event, route, alertText, text, status = false) {
            event.preventDefault();
            if (confirm(alertText)) {
                $.post(route, {_method: "PATCH", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {

                        if (!status) {
                            $(event.target).closest('.confirmation_status').text(status);
                            $(".confirmation_status").text(text);
                        } else {
                            $(".status").text(text);
                        }
                        $.toast({
                            heading: response.message,
                            text: text,
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    }).fail(function (response) {
                    $.toast({
                        heading: response.message,
                        text: "خطا در عملیات",
                        showHideTransition: 'fade',
                        icon: 'error'
                    })
                });
            }
        }


        function handleDeleteItem(event, route) {
            event.preventDefault();
            if (confirm('ایتم مورد نظر حذف شود؟')) {
                $.post(route, {_method: "delete", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {
                        event.target.closest('tr').remove();

                        $.toast({
                            heading: response.message,
                            text: 'ایتم مورد نظر با موفقیت حذف شد.',
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    })
                    .fail(function (response) {
                        $.toast({
                            heading: 'خطایی به وجود آمده است',
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    });
            }
        }

        function handleAcceptAll(route) {

            $("<form action='" + route + "' method='post'>" +
                "<input type='hidden' name='_token' value='" + $('meta[name="_token"]').attr('content') + "' /> " +
                "<input type='hidden' name='_method' value='patch'> " +
                "</form>").appendTo('body').submit();
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Course\Providers./../Resources/views/seasons/detail.blade.php ENDPATH**/ ?>