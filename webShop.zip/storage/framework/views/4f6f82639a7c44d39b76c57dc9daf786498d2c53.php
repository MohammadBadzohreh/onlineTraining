<?php echo e($slot); ?>

<?php /**PATH D:\projects\webShop\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>