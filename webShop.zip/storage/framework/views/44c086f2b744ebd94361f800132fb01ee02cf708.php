<select name="<?php echo e($name); ?>" class="text mb-0 mt-15">
   <?php echo e($slot); ?>

</select>
 <?php if (isset($component)) { $__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorMessage::class, ['field' => ''.e($name).'']); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822)): ?>
<?php $component = $__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822; ?>
<?php unset($__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH D:\projects\webShop\resources\views/components/select-box.blade.php ENDPATH**/ ?>