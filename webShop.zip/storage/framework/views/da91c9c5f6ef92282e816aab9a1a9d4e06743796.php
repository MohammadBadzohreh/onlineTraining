<div class="table__box padding-30">
    <table class="table">
        <thead role="rowgroup">
        <tr role="row" class="title-row">
            <th class="p-r-90">شناسه</th>
            <th>عنوان فصل</th>
            <th>وضعیت سرفصل</th>
            <th>حالت سرفصل</th>
            <th>عملیات</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $course->seassons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr role="row" class="">
                <td><a href="">1</a></td>
                <td><a href=""><?php echo e($season->title); ?></a></td>
                <td><a href="" class="confirmation_status"><?php echo app('translator')->get($season->confirmation_status); ?></a></td>
                <td><a href="" class="status"><?php echo app('translator')->get($season->status); ?></a></td>
                <td>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(\Badzohreh\RolePermissions\Models\Permission::PERMISSION_MANAGE_COURSES
                    || \Badzohreh\RolePermissions\Models\Permission::PERMISSION_SUPER_ADMIN
                    )): ?>
                        <a href="" class="item-delete mlg-15" title="حذف"></a>
                        <a href="" class="item-reject mlg-15" title="رد"
                           onclick="handleChangeStatus(event,'<?php echo e(route("season.reject",$season->id)); ?>','ایا مطمئن هستید؟','رد شده')"
                        ></a>
                        <a href="" class="item-confirm mlg-15" title="تایید"
                           onclick="handleChangeStatus(event,'<?php echo e(route("season.accpet",$season->id)); ?>','ایا مطمئن هستید؟','تایید شده')"></a>



                        <a href="" class="item-lock mlg-15 text-error" title="قفل"
                           onclick="handleChangeStatus(event,'<?php echo e(route("season.closed",$season->id)); ?>','ایا مطمئن هستید؟','قفل شده')"></a>


                        <a href="" class="item-lock mlg-15 text-success" title="باز"
                           onclick="handleChangeStatus(event,'<?php echo e(route("season.opened",$season->id)); ?>','ایا مطمئن هستید؟','باز')"></a>
                    <?php endif; ?>


                    <a href="<?php echo e(route("season.edit",$season->id)); ?>" class="item-edit " title="ویرایش"></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Course\Providers./../Resources/views/seasons/showSeasson.blade.php ENDPATH**/ ?>