<div class="col">
    <a href=<?php echo e($course->path()); ?>>
        <div class="course-status">
            <?php echo app('translator')->get($course->status); ?>
        </div>
        
            
            
        
        <div class="card-img" style="height: 250px"><img src="<?php echo e($course->banner->thumb); ?>" alt="<?php echo e($course->slug); ?>"></div>
        <div class="card-title"><h2><?php echo e($course->title); ?></h2></div>
        <div class="card-body">
            <img src="<?php echo e($course->teacher->thumb); ?>" alt="<?php echo e($course->teacher->name); ?>">
            <span><?php echo e($course->teacher->name); ?></span>
        </div>
        <div class="card-details">
            <div class="time"><?php echo e($course->getFormattedTime()); ?></div>
            <div class="price">
                <div class="discountPrice"><?php echo e($course->format_price()); ?></div>
                <div class="endPrice"><?php echo e($course->format_price()); ?></div>
            </div>
        </div>
    </a>
</div>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/courseCard.blade.php ENDPATH**/ ?>