<?php $__env->startComponent('mail::message'); ?>
# کد فعال سازی سایت وب آموز
این پیام جهت ارسال کد فعالسازی سایت وب آموز است

**در صورتی که در سایت عملیاتی انجام نداده اید این پیام را نادیده در نظر بگیرید.**
<?php $__env->startComponent('mail::panel'); ?>
    کد فعال سازی شما :<?php echo e($code); ?>

<?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

باتشکر,<br>
وب آموز
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\User\Providers./../Resources/Views/mails/verify-code.blade.php ENDPATH**/ ?>