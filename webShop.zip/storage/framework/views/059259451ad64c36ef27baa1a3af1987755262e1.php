<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="/css/modal.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>


    <main id="single">
        <div class="content">
            <div class="container">
                <article class="article">

                    

                    
                    
                    
                    <div class="h-t">
                        <h1 class="title"><?php echo e($course->title); ?></h1>
                        <div class="breadcrumb">
                            <ul>

                                <li><a href="/" title="خانه">خانه</a></li>
                                <?php if($course->category->category_parent): ?>
                                    <li><a href="<?php echo e($course->category->category_parent->path()); ?>"
                                           title="<?php echo e($course->category->category_parent->title); ?>">
                                            <?php echo e($course->category->category_parent->title); ?>

                                        </a>
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e($course->category->path()); ?>" title="<?php echo e($course->category->title); ?>">
                                        <?php echo e($course->category->title); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                </article>
            </div>


            <div class="main-row container">
                <div class="sidebar-right">
                    <div class="sidebar-sticky">
                        <div class="product-info-box">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if($course->teacher_id == auth()->id()): ?>
                                    <p class="mycourse">شما مدرس این دوره هستید</p>
                                <?php elseif(auth()->user()->can("download",$course)): ?>
                                    <p class="mycourse">شما این دوره رو خریداری کرده اید</p>
                                <?php else: ?>
                                    <div class="discountBadge">
                                        <p>45%</p>
                                        تخفیف
                                    </div>
                                    <div class="sell_course">
                                        <strong>قیمت :</strong>
                                        <del class="discount-Price"><?php echo e($course->getDiscountAmont()); ?></del>
                                        <p class="price">
                                    <span class="woocommerce-Price-amount amount"><?php echo e($course->getFinalPrice()); ?>

                                        <span class="woocommerce-Price-currencySymbol">تومان</span>
                                    </span>
                                        </p>
                                    </div>
                                    <button class="btn buy btn-buy">خرید دوره</button>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="discountBadge">
                                    <p>45%</p>
                                    تخفیف
                                </div>
                                <div class="sell_course">
                                    <strong>قیمت :</strong>
                                    <del class="discount-Price"><?php echo e($course->format_price()); ?></del>
                                    <p class="price">
                        <span class="woocommerce-Price-amount amount"><?php echo e($course->format_price()); ?>

                            <span class="woocommerce-Price-currencySymbol">تومان</span>
                        </span>
                                    </p>
                                </div>
                                <p>برای خرید دوره ابتدا در سایت ثبت نام کنید</p>
                                <a href="<?php echo e(route("login")); ?>" class="btn text-white w-100">ورود به سایت</a>

                            <?php endif; ?>

                            <div class="average-rating-sidebar">
                                <div class="rating-stars">
                                    <div class="slider-rating">
                                        <span class="slider-rating-span slider-rating-span-100" data-value="100%"
                                              data-title="خیلی خوب"></span>
                                        <span class="slider-rating-span slider-rating-span-80" data-value="80%"
                                              data-title="خوب"></span>
                                        <span class="slider-rating-span slider-rating-span-60" data-value="60%"
                                              data-title="معمولی"></span>
                                        <span class="slider-rating-span slider-rating-span-40" data-value="40%"
                                              data-title="بد"></span>
                                        <span class="slider-rating-span slider-rating-span-20" data-value="20%"
                                              data-title="خیلی بد"></span>
                                        <div class="star-fill"></div>
                                    </div>
                                </div>

                                <div class="average-rating-number">
                                    <span class="title-rate title-rate1">امتیاز</span>
                                    <div class="schema-stars">
                                        <span class="value-rate text-message"> 4 </span>
                                        <span class="title-rate">از</span>
                                        <span class="value-rate"> 555 </span>
                                        <span class="title-rate">رأی</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="product-info-box">
                            <div class="product-meta-info-list">
                                <div class="total_sales">
                                    تعداد دانشجو : <span><?php echo e(count($course->students)); ?></span>
                                </div>
                                <div class="meta-info-unit one">
                                    <span class="title">تعداد جلسات منتشر شده :  </span>
                                    <span class="vlaue"><?php echo e($course->lessonCount()); ?></span>
                                </div>
                                <div class="meta-info-unit two">
                                    <span class="title">مدت زمان دوره تا الان : </span>
                                    <span class="vlaue"><?php echo e($course->getFormattedTime()); ?></span>
                                </div>
                                <div class="meta-info-unit three">
                                    <span class="title">مدت زمان کل دوره : </span>
                                    <span class="vlaue">-</span>
                                </div>
                                <div class="meta-info-unit four">
                                    <span class="title">مدرس دوره : </span>
                                    <span class="vlaue"><?php echo e($course->teacher->name); ?></span>
                                </div>
                                <div class="meta-info-unit five">
                                    <span class="title">وضعیت دوره : </span>
                                    <span class="vlaue"><?php echo app('translator')->get($course->confirmation_status); ?></span>
                                </div>
                                <div class="meta-info-unit six">
                                    <span class="title">پشتیبانی : </span>
                                    <span class="vlaue">دارد</span>
                                </div>
                            </div>
                        </div>
                        <div class="course-teacher-details">
                            <div class="top-part">
                                <a href="<?php echo e(route("tutor" , $course->teacher->name)); ?>"><img
                                        alt="<?php echo e($course->teacher->name); ?>"
                                        class="img-fluid lazyloaded"
                                        src="img/profile.jpg"
                                        loading="lazy">
                                    <noscript>
                                        <img class="img-fluid" src="<?php echo e($course->teacher->thumb); ?>"
                                             alt="<?php echo e($course->teacher->name); ?>">
                                    </noscript>
                                </a>
                                <div class="name">
                                    <a href="<?php echo e(route("tutor" , $course->teacher->name)); ?>" class="btn-link">
                                        <h6><?php echo e($course->teacher->name); ?></h6>
                                    </a>
                                    <span class="job-title"><?php echo e($course->teacher->headline); ?></span>
                                </div>
                            </div>
                            <div class="job-content">
                                
                            </div>
                        </div>
                        <div class="short-link">
                            <div class="">
                                <span>لینک کوتاه</span>
                                <input class="short--link" value="<?php echo e($course->shortLink()); ?>">
                                <a href="" class="short-link-a" data-link="<?php echo e($course->shortLink()); ?>"></a>
                            </div>
                        </div>
                        <?php echo $__env->make("Front::layouts.sidebar-banners", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>
                <div class="content-left">
                    <?php if(!is_null($lesson)): ?>
                        <div class="preview">
                            <?php if($lesson->media->type === "video"): ?>
                                <video width="100%" controls>
                                    <source src="<?php echo e($lesson->downloadLink()); ?>" type="video/mp4">
                                </video>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e($lesson->downloadLink()); ?>" class="episode-download">دانلود این قسمت
                            (قسمت <?php echo e($lesson->number); ?>)</a>

                    <?php endif; ?>
                    <div class="course-description">

                        <div class="course-description-title">توضیحات دوره
                            <div class="study-mode"></div>
                        </div>
                        <p>
                            <?php echo $course->body; ?>

                        </p>

                        <div class="tags">
                            <ul>
                                <li><a href="">ری اکت</a></li>
                                <li><a href="">reactjs</a></li>
                                <li><a href="">جاوااسکریپت</a></li>
                                <li><a href="">javascript</a></li>
                                <li><a href="">reactjs چیست</a></li>
                            </ul>
                        </div>
                    </div>
                    <?php echo $__env->make("Front::layouts.episode-list", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

        <div id="Modal-buy" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <p>کد تخفیف را وارد کنید</p>
                    <div class="close">&times;</div>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(route("course.buy" , $course->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <div><input type="text" class="txt" placeholder="کد تخفیف را وارد کنید"></div>
                        <button class="btn i-t ">اعمال</button>

                        <table class="table text-center table-bordered table-striped">
                            <tbody>
                            <tr>
                                <th>قیمت کل دوره</th>
                                <td> <?php echo e($course->format_price()); ?> تومان</td>
                            </tr>
                            <tr>
                                <th>درصد تخفیف</th>
                                <td><?php echo e($course->getDiscountPercent()); ?>%</td>
                            </tr>
                            <tr>
                                <th> مبلغ تخفیف</th>
                                <td class="text-red"> <?php echo e($course->getDiscountAmont()); ?> تومان</td>
                            </tr>
                            <tr>
                                <th> قابل پرداخت</th>
                                <td class="text-blue"> <?php echo e($course->getFinalPrice()); ?> تومان</td>
                            </tr>
                            </tbody>
                        </table>
                        <button type="submit" class="btn btn i-t ">پرداخت آنلاین</button>
                    </form>
                </div>

            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="/js/modal.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Front::layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/single-course.blade.php ENDPATH**/ ?>