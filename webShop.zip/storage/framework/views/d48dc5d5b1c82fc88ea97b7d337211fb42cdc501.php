<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<script>
    Highcharts.chart('container', {
        chart: {
            renderTo: 'container',
            style: {
                fontFamily: 'irs',
                textAlign: "right",
            }
        },
        lang: {
            viewFullscreen: "نمایش تمام صفحه",
            printChart: "پرینت",
            downloadCSV: "دانلود csv",
            downloadJPEG: "دانلود تصویر (jpeg)",
            downloadPDF: "دانلود پی دی اف",
            downloadPNG: "دانلود تصویر (png)",
            downloadSVG: "دانلود تصویر (svg)",
            downloadXLS: "دانلود فایل excel",
            viewData: "نمایش به صورت جدول",
        }, tooltip: {
            useHTML: true,
            style: {
                direction: 'rtl',
                textAlign: "right",
            },
            formatter: function () {
                var mydate = this.x ? "تاریخ:" + "<span style='direction: ltr'>" + this.x + "</span><br />" : "";
                return mydate + "مبلغ:" + "<span style='margin-right: 10px'>" + this.y + "</span>";
            }
        }, title: {
            text: 'نمودار فروش 30 روز گذشته'
        },
        xAxis: {
            categories: [<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> '<?php echo e(\Morilog\Jalali\Jalalian::fromCarbon(\Illuminate\Support\Carbon::parse($date))->format("Y-m-d")); ?>', <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
        }, yAxis: {
            title: {
                text: "مبلغ",
                style: {
                    fontSize: '20px',
                    fontWeight: 'bold',
                }
            }, labels: {
                formatter: function () {
                    return this.value;
                }
            }
        },
        series: [{
            type: 'column',
            name: 'فروش سایت',
            color: '#red',
            data: [<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($day = $summry->where("date",$date)->first()): ?> <?php echo e($day->totalSiteShare); ?> <?php else: ?> 0  <?php endif; ?> , <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]
        }, {
            type: 'column',
            name: 'کل فروش',
            color: 'blue',

            data: [<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($day = $summry->where("date",$date)->first()): ?> <?php echo e($day->amount); ?> <?php else: ?> 0  <?php endif; ?> , <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]
        }, {
            type: 'column',
            name: 'فروش مدرس',
            color: 'pink',
            data: [<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($day = $summry->where("date",$date)->first()): ?> <?php echo e($day->totalSellerShare); ?> <?php else: ?> 0  <?php endif; ?> , <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>]
        }, {
            type: 'spline',
            name: 'فروش',
            color: '#fcd5ce',
            data: [<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($day = $summry->where("date",$date)->first()): ?> <?php echo e($day->amount); ?> <?php else: ?> 0  <?php endif; ?> , <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>],
            marker: {
                lineWidth: 2,
                lineColor: Highcharts.getOptions().colors[3],
                fillColor: 'white'
            }
        },]
    });
</script>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\Dashboard\Providers./../Resources/views/chart.blade.php ENDPATH**/ ?>