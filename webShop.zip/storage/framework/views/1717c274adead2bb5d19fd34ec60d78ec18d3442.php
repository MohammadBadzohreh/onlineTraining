<header class="t-header">
    <div class="campaign">
        <div class="container">
            <a class="message">تخفیف «۳۰٪» همه دوره‌ها فقط تا</a>
            <div id="count-down-timer" data-countdown="2020-07-8 00:00:00" class="count-down-timer"></div>
        </div>
    </div>
    <div class="container">
        <div class="t-header-row">
            <div class="t-header-right">
                <div class="t-header-logo"><a href="/"></a></div>
                <div class="t-header-search">
                    <div class="t-header-searchbox">
                        <input type="text" placeholder="جستجو دوره / مقاله / مدرس">
                        <div class="t-header-search-content">
                            <div class="t-header-search-result-filters">
                                <div class="t-header-search-filter-item f-all active"><span>همه (20)</span></div>
                                <div class="t-header-search-filter-item f-courses "><span>دوره ها (13)</span></div>
                                <div class="t-header-search-filter-item f-article "><span>مقاله ها (5)</span></div>
                                <div class="t-header-search-filter-item f-teacher "><span>مدرسین (2)</span></div>
                            </div>
                            <div class="t-header-search-result">
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                                <a href="">
                                    <div class="t-header-search-result-right">
                                        <p>دوره ساخت فریم ورک مشابه لاراول</p>
                                        <p class="t-header-search-result-right-info">
                                            مدرس دوره : محمد نیکو
                                        </p>
                                    </div>
                                    <div class="t-header-search-result-left">
                                        <img src="img/banner/laravel-payment-processing.jpg" alt="">
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="t-header-left">
                <div class="icons">
                    <div class="search-icon"></div>
                    <div class="menu-icon"></div>

                </div>

                <div class="join-teachers">
                    <a href="become-a-teacher.html">تدریس در وب آموز</a>
                </div>

                <?php if(auth()->guard()->check()): ?>
                    <div class="user-menu-account">
                        <div class="user-image">
                            <img src="<?php echo e(auth()->user()->thumb); ?>" alt="desction">
                        </div>
                        <span>پروفایل کاربری من </span>
                        <div class="user-menu-account-dropdown">
                            <ul>
                                <li><a href="">مشاهده پروفایل</a></li>
                                <li><a href="">خرید های من</a></li>
                                <li><a href="">داشبورد</a></li>
                                <li><a href="">خروج</a></li>
                            </ul>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="login-register-btn ">
                        <div><a class="btn-login" href="<?php echo e(route("login")); ?>">ورود</a></div>
                        <div><a class="btn-register" href="<?php echo e(route("register")); ?>">ثبت نام</a></div>
                    </div>

                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make("Front::layouts.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/header.blade.php ENDPATH**/ ?>