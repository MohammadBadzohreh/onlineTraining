

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('verification.verify')); ?>" class="form" method="post">
        <?php echo csrf_field(); ?>
        <a class="account-logo" href="index.html">
            <img src="img/weblogo.png" alt="">
        </a>
        <div class="card-header">
            <p class="activation-code-title">کد فرستاده شده به ایمیل <span><?php echo e(auth()->user()->email); ?></span> را وارد کنید
            </p>
        </div>
        <div>
            <p class="activation-code-title">اگر ایمیل خود را اشتباه وارد کرده اید
            <a href="<?php echo e(route("profile")); ?>">کلیک کنید</a>
            </p>
        </div>
        <div class="form-content form-content1">
            <input class="activation-code-input" name="verification_code" placeholder="فعال سازی">
            <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>
            <button class="btn i-t">تایید</button>
            <a href="#" onclick="event.preventDefault();
        document.getElementById('resned_verification_code').submit()">
                ارسال مجدد کد فعال سازی
            </a>


        </div>

        <div class="form-footer">
            <a href="<?php echo e(route('login')); ?>">صفحه ورود</a>
        </div>
    </form>
    <form id="resned_verification_code" action="<?php echo e(route('verification.resend')); ?>" method="post">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/js/jquery-3.4.1.min.js"></script>
    <script src="/js/activation-code.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User::Front.auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\User\Providers./../Resources/Views/Front/auth/verify.blade.php ENDPATH**/ ?>