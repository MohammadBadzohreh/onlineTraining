

<?php $__env->startSection("content"); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="breadcrumb">
            <ul>
                <li><a href="index.html" title="پیشخوان">پیشخوان</a></li>
            </ul>
        </div>
        <div class="main-content">
            <div class="row no-gutters">
                <div class="col-12 bg-white">
                    <p class="box__title">ایجاد دسته بندی جدید</p>
                    <form action="<?php echo e(route("categories.update",$category->id)); ?>" method="post" class="padding-30">
                        <?php echo method_field("patch"); ?>
                        <?php echo csrf_field(); ?>
                        <input type="text" name="title" required placeholder="نام دسته بندی"
                               class="text" value="<?php echo e($category->title); ?>">
                        <input type="text" name="slug" required placeholder="نام انگلیسی دسته بندی"
                               class="text" value="<?php echo e($category->slug); ?>">
                        <p class="box__title margin-bottom-15">انتخاب دسته پدر</p>
                        <select name="parent_id">
                            <option value="">ندارد</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoryItem->id); ?>" <?php if($categoryItem->title == $category->parent): ?> selected <?php endif; ?>><?php echo e($categoryItem->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <button type="submit" class="btn btn-webamooz_net">اضافه کردن</button>
                    </form>
                </div>

            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Category\Providers/../Resources/Views/edit.blade.php ENDPATH**/ ?>