<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-content">
            <form action="<?php echo e(route("settlement.store")); ?>" class="padding-30 bg-white font-size-14">
                <input type="text" name="name" placeholder="نام صاحب حساب" class="text">

                <input type="text" name="cart_number" placeholder="نام شماره کارت" class="text">

                <input type="text" name="amount" placeholder="مبلغ به تومان" class="text">

                <div class="row no-gutters border-2 margin-bottom-15 text-center ">
                    <div class="w-50 padding-20 w-50">موجودی قابل برداشت :‌</div>
                    <div class="bg-fafafa padding-20 w-50"><?php echo e(number_format(auth()->user()->balance)); ?> تومان</div>
                </div>
                <div class="row no-gutters border-2 text-center margin-bottom-15">
                    <div class="w-50 padding-20">حداکثر زمان واریز :‌</div>
                    <div class="w-50 bg-fafafa padding-20">۳ روز</div>
                </div>
                <button type="submit" class="btn btn-webamooz_net">درخواست تسویه</button>
            </form>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Payment\Providers./../Resources/Views/settlements/settlement.blade.php ENDPATH**/ ?>