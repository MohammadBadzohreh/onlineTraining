<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="/css/modal.css" />
<?php $__env->stopSection(); ?>

<main id="index">
    <div class="bt-0-top article mr-202"></div>
    <div class="bt-1-top">
        <div class="container">
            <div class="tutor">
                <div class="tutor-item">
                    <div class="tutor-avatar">
                        <span class="tutor-image" id="tutor-image"><img src="<?php echo e($tutor->thumb); ?>"
                                                                        class="tutor-avatar-img"></span>
                        <div class="tutor-author-name">
                            <a id="tutor-author-name" href="" title="<?php echo e($tutor->name); ?>">
                                <h3 class="title"><span class="tutor-author--name"><?php echo e($tutor->name); ?></span></h3>
                            </a>
                        </div>
                        <div id="Modal1" class="modal">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <div class="close">&times;</div>
                                </div>
                                <div class="modal-body">
                                    <img class="tutor--avatar--img" src="<?php echo e($tutor->thumb); ?>" alt="">
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="tutor-item">
                    <div class="stat">
                        <span class="tutor-number tutor-count-courses"><?php echo e(count($tutor->courses)); ?></span>
                        <span class="">تعداد دوره ها</span>
                    </div>
                    <div class="stat">

                        <span class="tutor-number"><?php echo e($tutor->studentsCount()); ?> </span>
                        <span class="">تعداد  دانشجویان</span>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="box-filter">
            <div class="b-head">
                <h2>دوره های <?php echo e($tutor->name); ?></h2>
            </div>
            <div class="posts">
                <?php $__currentLoopData = $tutor->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make("Front::layouts.courseCard",compact("course"), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</main>



<?php $__env->startSection("js"); ?>
    <script src="/js/modal.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Front::layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/tutor.blade.php ENDPATH**/ ?>