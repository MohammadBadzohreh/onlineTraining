<div class="top-info">
    <?php echo $__env->make("Front::layouts.slideShow", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="optionals">
        <div><img src="img/banner/1000024381.jpg" alt=""></div>
        <div><img src="img/banner/1000024381.jpg" alt=""></div>
    </div>
</div><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/top-info.blade.php ENDPATH**/ ?>