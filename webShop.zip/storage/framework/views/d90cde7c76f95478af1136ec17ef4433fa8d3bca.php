
<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="/panel/css/jquery.toast.min.css" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="main-content padding-0 categories">
            <div class="row no-gutters">
                <div class="col-12 margin-left-10 margin-bottom-15 border-radius-3">
                    <p class="box__title">دوره ها</p>
                    <div class="table__box">
                        <table class="table">
                            <thead role="rowgroup">
                            <tr role="row" class="title-row">
                                <th>بنر دوره</th>
                                <th>ای دی</th>
                                <th>عنوان دوره</th>
                                <th>ردیف</th>
                                <th>جزییات</th>
                                <th>مدرس دوره</th>
                                <th>قیمت دوره</th>
                                <th>حالت دوره</th>
                                <th>درصد مدرس</th>
                                <th>وضعیت دوره</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="">
                                    <td>
                                        <img src="<?php echo e($course->banner->thumb); ?>" alt="<?php echo e($course->title); ?>" width="150">
                                    </td>
                                    <td><a href=""><?php echo e($course->id); ?></a></td>
                                    <td><a href=""><?php echo e($course->title); ?></a></td>
                                    <td><a href=""><?php echo e($course->priority); ?></a></td>
                                    <td><a href="<?php echo e(route("seassons.index",$course->id)); ?>">جزییات</a></td>
                                    <td><?php echo e($course->teacher->name); ?></td>
                                    <td><?php echo e($course->price); ?></td>
                                    <td class="confirmation_status"><?php echo app('translator')->get($course->confirmation_status); ?></td>
                                    <td><?php echo e($course->percent); ?></td>
                                    <td class="status"><?php echo app('translator')->get($course->status); ?></td>
                                    <td>

                                        <a href="" target="_blank" class="item-eye mlg-15" title="مشاهده"></a>
                                        <a href="<?php echo e(route("course.edit",$course->id)); ?>" class="item-edit mlg-15"
                                           title="ویرایش"></a>


                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(\Badzohreh\RolePermissions\Models\Permission::PERMISSION_MANAGE_COURSES
                                                           || \Badzohreh\RolePermissions\Models\Permission::PERMISSION_SUPER_ADMIN
                                                           )): ?>                                            <a href="" class="item-delete mlg-15"
                                               onclick="handleDeleteItem(event,'<?php echo e(route('course.destroy',$course->id)); ?>')"
                                               title="حذف"></a>

                                            <a href=""
                                               onclick="handleChangeStatus(event,
                                                       '<?php echo e(route("course.change.accept",
                                                   $course->id)); ?>',
                                                       'ایا از تایید این دوره مطمئن هستید؟',
                                                       'تایید'
                                                       )"
                                               class="item-confirm mlg-15"
                                               title="تایید"></a>


                                            <a href=""
                                               onclick="handleChangeStatus(event,
                                                       '<?php echo e(route("course.change.rejected",
                                                   $course->id)); ?>',
                                                       'ایا از رد این دوره مطمئن هستید؟',
                                                       'رد'
                                                       )"
                                               class="item-reject mlg-15" title="رد"></a>


                                            <a href="" class="item-lock mlg-15"

                                               onclick="handleChangeStatus(event,
                                                       '<?php echo e(route("course.change.locked",
                                                   $course->id)); ?>',
                                                       'ایا از قفل این دوره مطمئن هستید؟',
                                                       'قفل',
                                                       true
                                                       )"

                                               title="قفل کردن"></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("js"); ?>

    <script src="/panel/js/jquery.toast.min.js" type="text/javascript"></script>
    <script>


        function handleChangeStatus(event, route, alertText,text,status = false) {
            event.preventDefault();
            if (confirm(alertText)) {
                $.post(route, {_method: "PATCH", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {

                        if (!status){
                            $(".confirmation_status").text(text);
                        } else {
                            $(".status").text(text);
                        }
                        $.toast({
                            heading: response.message,
                            text: text,
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    }).fail(function (response) {
                    $.toast({
                        heading: response.message,
                        text: "خطا در عملیات",
                        showHideTransition: 'fade',
                        icon: 'error'
                    })
                });


            }

        }
        function handleDeleteItem(event, route) {

            event.preventDefault();

            if (confirm('ایتم مورد نظر حذف شود؟')) {
                $.post(route, {_method: "delete", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {
                        event.target.closest('tr').remove();

                        $.toast({
                            heading: response.message,
                            text: 'ایتم مورد نظر با موفقیت حذف شد.',
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    })
                    .fail(function (response) {
                        $.toast({
                            heading: 'خطایی به وجود آمده است',
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    });
            }
        }


    </script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Course\Providers./../Resources/views/index.blade.php ENDPATH**/ ?>