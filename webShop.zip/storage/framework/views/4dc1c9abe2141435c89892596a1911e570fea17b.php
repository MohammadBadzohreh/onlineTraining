
<?php $__env->startSection("css"); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css"/>
    <link rel="stylesheet" href="/panel/css/jquery.toast.min.css" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="main-content padding-0 categories">
            <div class="row no-gutters">
                <div class="col-12 margin-left-10 margin-bottom-15 border-radius-3">
                    <p class="box__title">کاربران</p>
                    <div class="table__box">
                        <table class="table">
                            <thead role="rowgroup">
                            <tr role="row" class="title-row">
                                <th>ای دی</th>
                                <th>نام</th>
                                <th>شماره همراه</th>
                                <th>ایمیل</th>
                                <th>نقش کاربری</th>
                                <th>ip</th>
                                <th>تاریخ عضویت</th>
                                <th>وضعیت تایید</th>
                                <th>عملیات</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="">

                                    <td><a href=""><?php echo e($user->id); ?></a></td>
                                    <td><a href=""><?php echo e($user->name); ?></a></td>
                                    <td><?php echo e($user->mobile); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <ul>
                                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href=""><?php echo e($userRole->name); ?></a>
                                                    <a href=""
                                                       onclick="handleDeleteItem(event,
                                                               '<?php echo e(route("give.role.user",["user"=>$user->id,"role"=>$userRole->name])); ?>')"
                                                       class="item-delete mlg-15 deleteRole"></a>


                                                </li>
                                                <br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <p><a href="#rolsModal" rel="modal:open"
                                              onclick="setFormAction('<?php echo e($user->id); ?>')" data-modal>افزودن نقش کاربری</a>
                                        </p>
                                    </td>
                                    <td><?php echo e($user->ip); ?></td>
                                    <td><?php echo e($user->created_at); ?></td>
                                    <td class="confirmation-status"><?php echo $user->hasVerifiedEmail() ? "<span class='text-success'>تایید شده</span>" : "<span class='text-error'>تایید نشده</span>"; ?></td>
                                    <td>
                                        <a href="<?php echo e(route("users.edit",$user->id)); ?>" class="item-edit mlg-15"></a>
                                        <a href=""
                                           onclick="handleDeleteItem(event,'<?php echo e(route("users.destroy",$user->id)); ?>')"
                                           class="item-delete mlg-15"></a>

                                        <a href=""
                                           onclick="manualConfirm(event,'<?php echo e(route("users.manualConfirm",$user->id)); ?>')"
                                           class="item-confirm mlg-15"></a>
                                    </td>


                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>



    <div id="rolsModal" class="modal">
        <form id="selectModal" action="" method="post">
            <?php echo csrf_field(); ?>
            <select name="role" id="">
                <option value="" style="display: none;">نقش کاربری</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>


            <button type="submit" class="btn btn-webamooz_net">اضافه کردن</button>

        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
    <script src="/panel/js/jquery.toast.min.js" type="text/javascript"></script>

    <script>

        <?php if(session()->has("feedbacks")): ?>
        $.toast({
            heading: "<?php echo e(session()->get("feedbacks")["title"]); ?>",
            text: "<?php echo e(session()->get("feedbacks")["body"]); ?>",
            showHideTransition: 'slide',
            icon: 'success'
        });

        <?php endif; ?>




        function setFormAction(userId) {
            $("#selectModal").attr('action', "<?php echo e(route("add.role",0)); ?>".replace('/0/', '/' + userId + '/'))
        }

        function handleDeleteItem(event, route) {

            event.preventDefault();

            if (confirm('ایتم مورد نظر حذف شود؟')) {
                $.post(route, {_method: "delete", _token: "<?php echo e(csrf_token()); ?>"})
                    .done(function (response) {
                        event.target.closest('tr').remove();

                        $.toast({
                            heading: response.message,
                            text: 'ایتم مورد نظر با موفقیت حذف شد.',
                            showHideTransition: 'slide',
                            icon: 'success'
                        });
                    })
                    .fail(function (response) {
                        $.toast({
                            heading: 'خطایی به وجود آمده است',
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    });
            }
        }

        function manualConfirm(event, route) {
            event.preventDefault();
            $.post(route, {_method: "PATCH", _token: "<?php echo e(csrf_token()); ?>"})
                .done(function (response) {
                    $(".confirmation-status").html("<span class='text-success'>تایید شده</span>");
                    $.toast({
                        heading: response.message,
                        text: 'کاربر با موفقیت تغییر پیدا کرد.',
                        showHideTransition: 'slide',
                        icon: 'success'
                    });
                })
                .fail(function (response) {
                    $.toast({
                        heading: 'خطایی به وجود آمده است',
                        showHideTransition: 'fade',
                        icon: 'error'
                    })
                });
        }


    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<?php $__env->stopSection(); ?>










<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\User\Providers./../Resources/Views/users/detail.blade.php ENDPATH**/ ?>