<script src="/panel/js/jquery-3.4.1.min.js"></script>
<script src="/panel/js/js.js?v=<?php echo e(uniqid()); ?>"></script>
<?php echo $__env->yieldContent('js'); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Dashboard\Providers./../Resources/views/layouts/js.blade.php ENDPATH**/ ?>