<div class="sidebar__nav border-top border-left  ">
    <span class="bars d-none padding-0-18"></span>
    <a class="header__logo  d-none" href="https://webamooz.net"></a>
     <?php if (isset($component)) { $__componentOriginalf40418711a5c29a7e5becb33abe2e47e02282033 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UserProfile::class, []); ?>
<?php $component->withName('user-profile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf40418711a5c29a7e5becb33abe2e47e02282033)): ?>
<?php $component = $__componentOriginalf40418711a5c29a7e5becb33abe2e47e02282033; ?>
<?php unset($__componentOriginalf40418711a5c29a7e5becb33abe2e47e02282033); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <ul>
        <?php $__currentLoopData = config()->get("sidebar.items"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!array_key_exists('permission',$item)
            || auth()->user()->hasAnyPermission($item["permission"])
           || auth()->user()->hasPermissionTo(\Badzohreh\RolePermissions\Models\Permission::PERMISSION_SUPER_ADMIN)): ?>
                <li class="item-li <?php echo e($item["icon"]); ?> <?php if(request()->url() == $item['link']): ?> is-active <?php endif; ?>"><a
                            href="<?php echo e($item["link"]); ?>"><?php echo e($item["title"]); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

</div><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Dashboard\Providers./../Resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>