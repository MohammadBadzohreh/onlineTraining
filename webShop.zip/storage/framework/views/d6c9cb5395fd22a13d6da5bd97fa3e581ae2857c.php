
<div class="w-100 pr-5">
    <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" class="text mb-0 mt-15"
           value="<?php if($value): ?><?php echo e($value); ?><?php else: ?><?php echo e(old($name)); ?><?php endif; ?>"
           placeholder="<?php echo e($placeholder); ?>"
            <?php echo e($attributes->merge(["class"=>"text"])); ?>>
 <?php if (isset($component)) { $__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorMessage::class, ['field' => ''.e($name).'']); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822)): ?>
<?php $component = $__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822; ?>
<?php unset($__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>


<?php /**PATH D:\projects\webShop\resources\views/components/input.blade.php ENDPATH**/ ?>