<div class="file-upload mb-0 mt-15">
    <div class="i-file-upload">
        <span><?php echo e($title); ?></span>
        <input type="file" class="file-upload" id="files" name="<?php echo e($name); ?>" <?php echo e($attributes); ?> />
    </div>


    <span class="filesize"></span>
    <?php if(!empty($value)): ?>
        <span class="selectedFiles">فایل فعلی</span>
        <span><?php echo e($value->file_name); ?></span>
        <img src="<?php echo e($value->thumb); ?>" width="100" height="100" alt="<?php echo e($value->file_name); ?>">
    <?php else: ?>
        <span class="selectedFiles">فایلی انتخاب نشده است</span>

    <?php endif; ?>


</div>
 <?php if (isset($component)) { $__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ErrorMessage::class, ['field' => ''.e($name).'']); ?>
<?php $component->withName('error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822)): ?>
<?php $component = $__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822; ?>
<?php unset($__componentOriginal3facbb459eedf29b74ea41c525678e34bdd4b822); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH D:\projects\webShop\resources\views/components/uploaded-file.blade.php ENDPATH**/ ?>