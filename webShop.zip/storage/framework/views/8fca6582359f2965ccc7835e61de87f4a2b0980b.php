<div class="episodes-list">
    <div class="episodes-list--title">
        فهرست جلسات

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("download",$course)): ?>
            <span class="text-info" style="font-size: 0.8em">
            <a href="<?php echo e(route("download.course",$course->id)); ?>">
            دریافت همه لینک های دانلود
            </a>
        </span>
        <?php endif; ?>

    </div>
    <div class="episodes-list-section">
        <div class="episodes-list-group">
            <div class="episodes-list-group-head">
                <div class="head-right">
                    <span class="section-name">بخش اول </span>
                    <div class="section-title">پیاده سازی بخش بک اند پروژه آپارات</div>
                    <span class="episode-count"> 10 ویدیو </span>
                </div>
                <div class="head-left"></div>
            </div>
            <div class="episodes-list-group-body">
                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="episodes-list-item <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies("download",$lesson)): ?> lock <?php endif; ?>">
                        <div class="section-right">
                            <span class="episodes-list-number"><?php echo e($lesson->number); ?></span>
                            <div class="episodes-list-title">
                                <a href="<?php echo e($lesson->path()); ?>"><?php echo e($lesson->title); ?></a>
                            </div>
                        </div>
                        <div class="section-left">
                            <div class="episodes-list-details">
                                <div class="episodes-list-details">
                                    <span class="detail-type"><?php echo e($lesson->is_free ? "رایگان" : "نقدی"); ?></span>
                                    <span class="detail-time"><?php echo e($lesson->durationTime()); ?></span>
                                    <a class="detail-download"
                                       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("download" , $lesson)): ?> href="<?php echo e($lesson->downloadLink()); ?>" <?php endif; ?>>
                                        <i class="icon-download"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\projects\webShop\moduls\Badzohreh\Front\Providers./../Resources/Views/layouts/episode-list.blade.php ENDPATH**/ ?>