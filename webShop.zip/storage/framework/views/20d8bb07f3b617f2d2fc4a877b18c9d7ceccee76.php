<div class="breadcrumb">
    <ul>
        <li><a href="<?php echo e(route("home")); ?>" title="پیشخوان">پیشخوان</a></li>
    </ul>
</div><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Dashboard\Providers./../Resources/views/layouts/breadcrumb.blade.php ENDPATH**/ ?>