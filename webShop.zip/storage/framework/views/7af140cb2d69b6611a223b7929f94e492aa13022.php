<?php echo e($slot); ?>

<?php /**PATH D:\projects\webShop\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>