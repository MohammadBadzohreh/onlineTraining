

<?php $__env->startSection("content"); ?>
    <div class="content">
        <?php echo $__env->make("Dashboard::layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make("Dashboard::layouts.breadcrumb", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content padding-0">
            <p class="box__title">ایجاد درس جدید</p>
            <div class="row no-gutters bg-white">
                <div class="col-12">
                    <form action="" method="post" enctype="multipart/form-data" class="padding-30">
                        <?php echo csrf_field(); ?>

                         <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'title','placeholder' => 'عنوان درس']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'text','name' => 'slug','placeholder' => 'نام انگلیسی درس']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left','required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                         <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'number','name' => 'time','placeholder' => 'مدت زمان جلسه *']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left','required' => true]); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Input::class, ['type' => 'number','name' => 'number','placeholder' => 'شماره جلسه']); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'text-left']); ?>
<?php if (isset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7)): ?>
<?php $component = $__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7; ?>
<?php unset($__componentOriginal11c02d5af8eef3b9ca8b54c54983d5cb581e68d7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                        <div class="w-50">
                            <p class="box__title">ایا این درس رایگان است ؟ </p>
                            <div class="notificationGroup">
                                <input id="lesson-upload-field-1" name="is_free" value="1" type="radio" checked="">
                                <label for="lesson-upload-field-1">خیر</label>
                            </div>
                            <div class="notificationGroup">
                                <input id="lesson-upload-field-2" name="is_free" value="0" type="radio">
                                <label for="lesson-upload-field-2">بله</label>
                            </div>
                        </div>


                        <?php if(count($seassons)): ?>

                         <?php if (isset($component)) { $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SelectBox::class, ['name' => 'season_id']); ?>
<?php $component->withName('select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                            <option value="">سرفصل ها</option>
                            <?php $__currentLoopData = $seassons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seasson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($seasson->id); ?>"><?php echo e($seasson->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756)): ?>
<?php $component = $__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756; ?>
<?php unset($__componentOriginaldb7526e5ed4b3e7f268c0556046396a34c4ea756); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endif; ?>
                         <?php if (isset($component)) { $__componentOriginal39539b0b265662580341faed89579bf8b84763bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\UploadedFile::class, ['name' => 'lesson-upload','title' => 'آپلود درس']); ?>
<?php $component->withName('uploaded-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['required' => true]); ?>
<?php if (isset($__componentOriginal39539b0b265662580341faed89579bf8b84763bd)): ?>
<?php $component = $__componentOriginal39539b0b265662580341faed89579bf8b84763bd; ?>
<?php unset($__componentOriginal39539b0b265662580341faed89579bf8b84763bd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                         <?php if (isset($component)) { $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Textarea::class, ['placeholder' => 'توضیحات درس','name' => 'body']); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890)): ?>
<?php $component = $__componentOriginalada24a059c331be0784ec187913c2ecfacd51890; ?>
<?php unset($__componentOriginalada24a059c331be0784ec187913c2ecfacd51890); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <br>
                        <button class="btn btn-webamooz_net">ایجاد درس</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="js/tagsInput.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("Dashboard::master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Course\Providers./../Resources/views/lessons/create.blade.php ENDPATH**/ ?>