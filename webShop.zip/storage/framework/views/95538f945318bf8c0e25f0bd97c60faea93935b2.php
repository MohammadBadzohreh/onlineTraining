<form id="profileForm" action="<?php echo e(route("userProfileImage")); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="profile__info border cursor-pointer text-center">
        <div class="avatar__img"><img src="<?php if(auth()->user()->banner): ?><?php echo e(auth()->user()->banner->thumb); ?><?php else: ?>/panel/img/pro.jpg <?php endif; ?>" class="avatar___img">
            <input type="file" accept="image/*"
                   class="hidden avatar-img__input"
                   name="image"
                   onchange="$('#profileForm').submit()">
            <div class="v-dialog__container" style="display: block;"></div>
            <div class="box__camera default__avatar"></div>
        </div>
        <span class="profile__name">کاربر : <?php echo e(auth()->user()->name); ?></span>
    </div>
</form>
<?php /**PATH D:\projects\webShop\resources\views/components/user-profile.blade.php ENDPATH**/ ?>