<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('Dashboard::layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<?php echo $__env->make('Dashboard::layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent("content"); ?>
</body>
<?php echo $__env->make('Dashboard::layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH D:\projects\webShop\moduls\Badzohreh\Dashboard\Providers./../Resources/views/master.blade.php ENDPATH**/ ?>