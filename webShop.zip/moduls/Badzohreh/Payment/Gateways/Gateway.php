<?php

namespace Badzohreh\Payment\Gateways;

class Gateway
{

}
