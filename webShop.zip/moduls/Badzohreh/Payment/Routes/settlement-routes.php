<?php
Route::group([], function ($router) {
    $router->get("/payments/settlement/create", "SettlementController@create")->name("settlement.create");
    $router->post("/payments/settlement/store", "SettlementController@store")->name("settlement.store");
});
