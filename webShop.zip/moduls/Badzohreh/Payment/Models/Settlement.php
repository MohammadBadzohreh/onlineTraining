<?php

namespace Badzohreh\Payment\Models;

use Illuminate\Database\Eloquent\Model;

class Settlement extends Model
{
    const STATUS_PENDING = "pending";
    const STATUS_SATTELED = "satteled";
    const STATUS_CANCELLED = "cancelled";
    const STATUS_REJECTED = "rejected";

    public static $STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_SATTELED,
        self::STATUS_CANCELLED,
        self::STATUS_REJECTED,
    ];
}
