<?php
return [

    "items"=>[
        "dashboard"=>[],
        "category"=>[],
        "Rolepermissions"=>[],
        "course"=>[],
        "users"=>[],
        "profile"=>[],
        "payments"=>[],
    ]
];
