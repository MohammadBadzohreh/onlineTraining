<article class="container blog">
    <div class="b-head">
        <h2>آخرین مقالات</h2>
        <a href="https://webamooz.net/blog">مشاهده همه</a>
    </div>
    <div class="articles">
        <div class="col">
            <a href="react.html">
                <div class="card-img"><img src="img/banner/reactjs.png" alt="reactjs"></div>
                <div class="card-title"><h2>
                        فاسد در فریم ورک لاراول
                    </h2></div>
                <div class="card-body">

                </div>
                <div class="card-details">
                    <span class="b-view">80</span>
                    <span class="b-category">دسته بندی : وب</span>
                </div>
            </a>
        </div>
        <div class="col">
            <a href="react.html">
                <div class="card-img"><img src="img/banner/reactjs.png" alt="reactjs"></div>
                <div class="card-title"><h2>
                        فاسد در فریم ورک لاراول
                    </h2></div>
                <div class="card-body">

                </div>
                <div class="card-details">
                    <span class="b-view">80</span>
                    <span class="b-category">دسته بندی : وب</span>
                </div>
            </a>
        </div>
        <div class="col">
            <a href="react.html">
                <div class="card-img"><img src="img/banner/reactjs.png" alt="reactjs"></div>
                <div class="card-title"><h2>
                        فاسد در فریم ورک لاراول
                    </h2></div>
                <div class="card-body">

                </div>
                <div class="card-details">
                    <span class="b-view">80</span>
                    <span class="b-category">دسته بندی : وب</span>
                </div>
            </a>
        </div>
        <div class="col">
            <a href="react.html">
                <div class="card-img"><img src="img/banner/reactjs.png" alt="reactjs"></div>
                <div class="card-title"><h2>
                        فاسد در فریم ورک لاراول
                    </h2></div>
                <div class="card-body">

                </div>
                <div class="card-details">
                    <span class="b-view">80</span>
                    <span class="b-category">دسته بندی : وب</span>
                </div>
            </a>
        </div>
    </div>
</article>