<div class="ads d-none">
    <a href="" rel="nofollow noopener"><img src="img/ads/1440px/test.jpg" alt=""></a>
</div>