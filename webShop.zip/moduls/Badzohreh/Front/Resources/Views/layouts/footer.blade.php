<div class="toast">
    <div>
        <div class="toast__icon"></div>
        <div class="toast__message"></div>
        <div class="toast__close" onclick="toast__close()" ></div>
    </div>


</div>

<footer>
    <a class="scrollToTop"></a>
    <div class="container">
        <div class="f-links">
            <div class="col--2"><a href="">خدمات هاستینگ بستلا</a></div>
            <div class="col--2"><a href="">لینک اول</a></div>
            <div class="col--2"><a href="">لینک اول</a></div>
            <div class="col--2"><a href="">لینک اول</a></div>
            <div class="col--2"><a href="">لینک اول</a></div>
            <div class="col--2"><a href="">لینک اول</a></div>
        </div>
    </div>
    <div class="line"></div>
    <div class="container">
        <div class="f-about">
            <div class="col--8">
                <p>
                    وب اموز مرجعی تخصصی برای یادگیری طراحی و برنامه نویسی وب و موبایل است. ما در وب اموز با بهره گیری از
                    نیروهای متخصص، باتجربه تمام تلاش خود را برای تهیه و تولید آموزش های با کیفیت و کامل و حرفه ای انجام
                    می دهیم. باور ما اینست که کاربران ایرانی لایق بهترین ها هستند و باید بهترین و بروزترین فیلم های
                    آموزشی، در اختیار آنها قرار بگیرد تا بتوانند به سرعت پیشرفت کنند و جزء بهترین ها شوند. امید است که
                    با همراهی هر چه بیشتر شما کاربران عزیز در این راه، ما را برای حرکتی قدرتمند در مسیر این هدف باارزش
                    یاری دهید.
                </p>
            </div>
        </div>
    </div>
    <div class="webamooz">
        طراحی و توسعه با لاراول توسط تیم
        <a href="https://webamooz.net">وب آموز</a>
        © 1399
    </div>
</footer>
