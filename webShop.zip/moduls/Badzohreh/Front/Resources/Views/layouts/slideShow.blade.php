<div class="slideshow">
    <div class="slide"><img src="img/slideshow/p-1.jpg" alt=""></div>
    <div class="slide"><img src="img/slideshow/p-2.jpg" alt=""></div>
    <div class="slide"><img src="img/slideshow/p-3.jpg" alt=""></div>
    <div class="slide"><img src="img/slideshow/p-4.jpg" alt=""></div>
    <div class="slide"><img src="img/slideshow/p-5.jpg" alt=""></div>

    <a class="prev" onclick="move(-1)"><span>&#10095</span></a>
    <a class="next" onclick="move(1)"><span>&#10094</span></a>

    <div class="items">
        <div class="item">
            <div class="item-inner"></div>
        </div>
        <div class="item">
            <div class="item-inner"></div>
        </div>
        <div class="item">
            <div class="item-inner"></div>
        </div>
        <div class="item">
            <div class="item-inner"></div>
        </div>
        <div class="item">
            <div class="item-inner"></div>
        </div>
    </div>
</div>
