<div class="top-info">
    @include("Front::layouts.slideShow")
    <div class="optionals">
        <div><img src="img/banner/1000024381.jpg" alt=""></div>
        <div><img src="img/banner/1000024381.jpg" alt=""></div>
    </div>
</div>