<select name="{{$name}}" class="text mb-0 mt-15">
   {{$slot}}
</select>
<x-error-message field="{{$name}}" />
